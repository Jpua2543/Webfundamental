console.log(jd)

function clicked(element){
console.log(element.innerText)
element.innerText="John Pua"
}

function hide(element) {
    element.remove();
}
