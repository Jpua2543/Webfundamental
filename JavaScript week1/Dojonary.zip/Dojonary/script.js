console.log()

function logout(element) {
    element.innerText ="Logout";
}
function popout(x) {
    console.log("element clicked", x);
    alert(x);
}

function remove(element) {
    element.remove();
}

