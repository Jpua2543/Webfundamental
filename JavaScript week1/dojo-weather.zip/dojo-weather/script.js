function hide(element) {
    element.remove();
}
function selecttemp(){
    var x = document.getElementById("converttemp").value;
    var result = document.getElementsByClassName("cel");
    result.innerText = (“test”);